STEP_DECORATORS_DESC = [
    ("test_step_decorator", ".test_step_decorator.TestStepDecorator"),
]

FLOW_DECORATORS_DESC = [
    ("test_flow_decorator", ".flow_options.FlowDecoratorWithOptions"),
]

__mf_promote_submodules__ = ["nondecoplugin", "frameworks"]
